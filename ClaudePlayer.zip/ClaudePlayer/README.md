# Claude Player (Android app)
Upload this project to GitHub -> Actions tab -> "Build APK" -> download `ClaudePlayer-apk` from the run's Artifacts -> install.
In the app: 1) enable accessibility, 2) paste Anthropic API key, 3) Start, then open your game.
Taps in the top bar and bottom power-up row are blocked so it can't spend coins.
