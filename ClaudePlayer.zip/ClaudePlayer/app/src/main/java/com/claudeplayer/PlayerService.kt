package com.claudeplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class PlayerService : AccessibilityService() {
    companion object {
        @Volatile var instance: PlayerService? = null
        @Volatile var log = ""
        const val MODEL = "claude-sonnet-5-5"
        const val W = 540
        const val SYSTEM = """You are playing a mobile puzzle game (Pixel Flow style) by looking at screenshots and tapping.
RULES: The framed picture is made of colored pixel blocks. Colored "pig" shooters on the conveyor belt shoot blocks of THEIR OWN color. Each pig's number = ammo. Pigs wait in a grid at the bottom; tap a pig that is NOT covered by another pig to send it onto the belt. The belt holds limited pigs (e.g. 5/5); if full, wait.
STRATEGY: pick pigs whose color matches blocks exposed on the outer edge of the picture; prefer enough ammo to clear a region; don't waste belt slots on colors with nothing exposed.
SCREENS: menu with yellow Play -> tap Play. Win/Continue/Next -> tap it. Fail -> free retry/close, never pay. Popups -> close with X / No thanks. Never watch ads on purpose.
NEVER tap anything that costs coins/money: "+" buttons, bottom power-up buttons, No Ads, shop, gift offers.
Answer by calling the act tool. Coordinates are pixels of the image shown (origin top-left), tap the center. If nothing useful can be done now, action "wait"."""
        const val TOOL = """{"name":"act","description":"Report what you see and choose the next action.","input_schema":{"type":"object","properties":{"screen_state":{"type":"string","enum":["menu","gameplay","popup","win","fail","loading","unknown"]},"observation":{"type":"string"},"reasoning":{"type":"string"},"action":{"type":"string","enum":["tap","wait"]},"x":{"type":"integer"},"y":{"type":"integer"}},"required":["screen_state","observation","reasoning","action"]}}"""
    }

    @Volatile private var running = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; running = false; return super.onUnbind(i) }

    private fun say(m: String) { log = (log + m + "\n").takeLast(4000) }

    fun stop() { running = false; say("Stopping...") }

    fun start(key: String, maxSteps: Int, dry: Boolean) {
        if (running) return
        if (key.isEmpty()) { say("Enter your API key first"); return }
        running = true; log = ""
        Thread { loop(key, maxSteps, dry) }.start()
    }

    private fun shot(): Bitmap? {
        var out: Bitmap? = null
        val latch = CountDownLatch(1)
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val bm = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                out = bm?.copy(Bitmap.Config.ARGB_8888, false)
                r.hardwareBuffer.close(); latch.countDown()
            }
            override fun onFailure(c: Int) { latch.countDown() }
        })
        latch.await(10, TimeUnit.SECONDS)
        return out
    }

    private fun ask(key: String, img: Bitmap, hist: List<String>, stuck: Boolean): JSONObject {
        val bo = ByteArrayOutputStream(); img.compress(Bitmap.CompressFormat.JPEG, 75, bo)
        var note = if (hist.isNotEmpty()) "Last actions:\n" + hist.takeLast(6).joinToString("\n") + "\n" else ""
        if (stuck) note += "WARNING: screen did not change after your last tap. Try something different or wait.\n"
        note += "Image size: ${img.width}x${img.height}. Decide the next action."
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64")
                .put("media_type", "image/jpeg").put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP))))
            .put(JSONObject().put("type", "text").put("text", note))
        val body = JSONObject().put("model", MODEL).put("max_tokens", 800).put("system", SYSTEM)
            .put("tools", JSONArray().put(JSONObject(TOOL)))
            .put("tool_choice", JSONObject().put("type", "tool").put("name", "act"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 90000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}: " + (c.errorStream?.bufferedReader()?.readText() ?: "").take(200))
        val arr = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("content")
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("type") == "tool_use") return arr.getJSONObject(i).getJSONObject("input")
        return JSONObject("""{"screen_state":"unknown","observation":"","reasoning":"no tool call","action":"wait"}""")
    }

    private fun tap(x: Int, y: Int) {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }

    private fun loop(key: String, maxSteps: Int, dry: Boolean) {
        say("Starting in 5s - switch to your game now"); Thread.sleep(5000)
        val hist = ArrayList<String>(); var last = 0; var n = 0; var fails = 0
        while (running && n < maxSteps) {
            n++
            val full = shot()
            if (full == null) { say("Screenshot failed"); Thread.sleep(2000); continue }
            val scale = full.width.toDouble() / W
            val small = Bitmap.createScaledBitmap(full, W, Math.round(full.height / scale).toInt(), true)
            val px = IntArray(54 * 120); Bitmap.createScaledBitmap(small, 54, 120, true).getPixels(px, 0, 54, 0, 0, 54, 120)
            val hsh = px.contentHashCode(); val stuck = hsh == last; last = hsh
            val d = try { ask(key, small, hist, stuck); } catch (e: Exception) {
                say("API error: ${e.message}"); if (++fails >= 5) { say("Too many errors, stopping"); break }
                Thread.sleep(3000); continue
            }
            fails = 0
            val state = d.optString("screen_state", "unknown"); var action = d.optString("action", "wait")
            var why = d.optString("reasoning", ""); var tapped = false
            if (action == "tap" && d.has("x") && d.has("y")) {
                val x = d.getInt("x"); val y = d.getInt("y"); val fy = y.toDouble() / small.height
                val menu = state in listOf("menu", "win", "fail", "popup")
                if (fy < 0.09 || fy > 0.93 || (fy > 0.90 && !menu)) { why += " [BLOCKED by safety rail]"; action = "wait" }
                else { tapped = true; if (!dry) tap((x * scale).toInt(), (y * scale).toInt()) }
            }
            hist.add("#$n $state: $action - ${why.take(90)}")
            say("#$n [$state] $action ${d.optString("x")},${d.optString("y")} | $why")
            Thread.sleep(if (tapped) 1000 else 1500)
        }
        running = false; say("Done")
    }
}
