package com.claudeplayer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cp", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        val key = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(p.getString("key", ""))
        }
        val steps = EditText(this).apply {
            hint = "Max steps"; inputType = InputType.TYPE_CLASS_NUMBER; setText(p.getString("steps", "100"))
        }
        val dry = CheckBox(this).apply { text = "Dry run (think, don't tap)" }
        val bAcc = Button(this).apply {
            text = "1. Enable accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val bStart = Button(this).apply {
            text = "2. Start (open your game now)"
            setOnClickListener {
                val s = PlayerService.instance
                if (s == null) { Toast.makeText(context, "Enable accessibility first", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                p.edit().putString("key", key.text.toString().trim()).putString("steps", steps.text.toString()).apply()
                s.start(key.text.toString().trim(), steps.text.toString().toIntOrNull() ?: 100, dry.isChecked)
                moveTaskToBack(true)
            }
        }
        val bStop = Button(this).apply { text = "Stop"; setOnClickListener { PlayerService.instance?.stop() } }
        logView = TextView(this).apply { textSize = 12f }
        listOf(key, steps, dry, bAcc, bStart, bStop, ScrollView(this).apply { addView(logView) }).forEach { col.addView(it) }
        setContentView(col)
    }

    override fun onResume() {
        super.onResume()
        h.post(object : Runnable {
            override fun run() { logView.text = PlayerService.log; h.postDelayed(this, 1000) }
        })
    }

    override fun onPause() { super.onPause(); h.removeCallbacksAndMessages(null) }
}
